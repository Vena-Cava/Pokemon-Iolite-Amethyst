#===============================================================================
# Keybind menu scene
#===============================================================================
class KeybindListScene
  ACTIONS = [
    [:use,     _INTL("Confirm")],
    [:back,    _INTL("Back")],
    [:action,  _INTL("Menu")],
    [:special, _INTL("Special")],
    [:up,      _INTL("Up")],
    [:down,    _INTL("Down")],
    [:left,    _INTL("Left")],
    [:right,   _INTL("Right")],
    [:jumpup,  _INTL("Page Up")],
    [:jumpdown,_INTL("Page Down")]
  ]

  def initialize(device)
    @device = device
  end

  def pbStartScene
    @viewport = Viewport.new(0, 0, Graphics.width, Graphics.height)
    @viewport.z = 99999
    @sprites = {}

    title = (@device == :keyboard) ? _INTL("Keyboard Bindings") : _INTL("Controller Bindings")

    addBackgroundOrColoredPlane(@sprites, "bg", "optionsbg", Color.new(192, 200, 208), @viewport)

    @sprites["title"] = Window_UnformattedTextPokemon.newWithSize(
      title, 0, -16, Graphics.width, 64, @viewport
    )
    @sprites["title"].back_opacity = 0

    commands = ACTIONS.map { |action, name| format_command(action, name) }
    commands.push(_INTL("Close"))

    @sprites["cmds"] = Window_CommandPokemon.new(commands)
    @sprites["cmds"].x = 0
    @sprites["cmds"].y = @sprites["title"].height - 16
    @sprites["cmds"].width = Graphics.width
    @sprites["cmds"].height = Graphics.height - @sprites["cmds"].y
    @sprites["cmds"].viewport = @viewport

    pbFadeInAndShow(@sprites) { pbUpdate }
  end

  def format_command(action, name)
    button = if @device == :keyboard
               Keybinds::KEYBOARD_NAMES[action] || "?"
             else
               Keybinds::GAMEPAD_NAMES[action] || "?"
             end
    return _INTL("{1}: {2}", name, button)
  end

  def pbMain
    loop do
      Graphics.update
      Input.update
      Keybinds.update if defined?(Keybinds)
      pbUpdate

      if Keybinds.trigger?(:back)
        break
      elsif Keybinds.trigger?(:use)
        break if @sprites["cmds"].index == ACTIONS.length
        action = ACTIONS[@sprites["cmds"].index][0]
        pbPlayDecisionSE

        if @device == :controller
          pbMessage(_INTL("Press a controller button for {1}.", ACTIONS[@sprites["cmds"].index][1]))
          button = Keybinds.wait_for_controller_button
          Keybinds.set_controller_binding(action, button)
          refresh_commands
        else
          pbMessage(_INTL("Keyboard rebinding will be added next."))
        end
        pbPlayDecisionSE
      end
    end
  end
  
  def controller_button_name(button)
    names = {
      0  => "A",
      1  => "B",
      2  => "X",
      3  => "Y",
      4  => "Select",
      6  => "Start",
      7  => "LS",
      8  => "RS",
      9  => "LB",
      10 => "RB",
      11 => "D-Up",
      12 => "D-Down",
      13 => "D-Left",
      14 => "D-Right"
    }
    return names[button] || "Button #{button}"
  end

  def refresh_commands
    commands = ACTIONS.map { |action, name| format_command(action, name) }
    commands.push(_INTL("Close"))
    @sprites["cmds"].commands = commands
    @sprites["cmds"].refresh
  end

  def pbUpdate
    pbUpdateSpriteHash(@sprites)
  end

  def pbEndScene
    pbFadeOutAndHide(@sprites) { pbUpdate }
    pbDisposeSpriteHash(@sprites)
    @viewport.dispose
  end
end

#===============================================================================
# Screen wrapper
#===============================================================================
class KeybindListScreen
  def initialize(scene)
    @scene = scene
  end

  def pbStartScreen
    @scene.pbStartScene
    @scene.pbMain
    @scene.pbEndScene
  end
end