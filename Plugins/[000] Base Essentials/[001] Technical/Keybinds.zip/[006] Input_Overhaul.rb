module Keybinds
  DEVICE_KEYBOARD = :keyboard
  DEVICE_GAMEPAD  = :gamepad

  @last_device = DEVICE_KEYBOARD

  @last_button_states = {}

  @repeat_count = {}

  ACTIONS = {
    :use => Input::USE,
    :back => Input::BACK,
    :action => Input::ACTION,
    :special => Input::SPECIAL,
    :left => Input::LEFT,
    :right => Input::RIGHT,
    :up => Input::UP,
    :down => Input::DOWN,
    :jumpup => Input::JUMPUP,
    :jumpdown => Input::JUMPDOWN
  }

  GAMEPAD_BUTTONS = {
    :use     => 0,   # A
    :back    => 1,   # B
    :action  => 6,   # Start
    :special => 3,   # Y
    :jumpup  => 9,   # LB
    :jumpdown=> 10,  # RB
    :up      => 11,
    :down    => 12,
    :left    => 13,
    :right   => 14
  }
  
  GAMEPAD_NAMES = {
    :use     => "A",
    :back    => "B",
    :action  => "Start",
    :special => "Y",
    :aux1    => "LB",
    :aux2    => "RB",
    :up      => "D-Up",
    :down    => "D-Down",
    :left    => "D-Left",
    :right   => "D-Right",
    :jumpup      => "Page Up",
    :jumpdown    => "Page Down",
  }

  GAMEPAD_BUTTON_NAMES = {
    0  => "A",
    1  => "B",
    2  => "X",
    3  => "Y",
    4  => "Select",
    5  => "Guide",
    6  => "Start",
    7  => "LS",
    8  => "RS",
    9  => "LB",
    10 => "RB",
    11 => "D-Up",
    12 => "D-Down",
    13 => "D-Left",
    14 => "D-Right",
    15 => "LT",
    16 => "RT"
  }

  KEYBOARD_NAMES = {
    :use     => "Z/Enter",
    :back    => "X/Esc",
    :action  => "Shift",
    :special => "D",
    :aux1    => "Q",
    :aux2    => "W",
    :jumpup  => "A",
    :jumpdown=> "S"
  }
  
  def self.update
    # Detect controller buttons/sticks/triggers
    if defined?(Input::Controller) && Input::Controller.connected?
      buttons = Input::Controller.raw_button_states
      left    = Input::Controller.axes_left rescue [0.0, 0.0]
      right   = Input::Controller.axes_right rescue [0.0, 0.0]
      trigger = Input::Controller.axes_trigger rescue [0.0, 0.0]

      if buttons.any? { |b| b } ||
        left.any? { |v| v.abs > 0.25 } ||
        right.any? { |v| v.abs > 0.25 } ||
        trigger.any? { |v| v.abs > 0.25 }

        @last_device = DEVICE_GAMEPAD
        return
      end
    end

    # Detect keyboard
    if Input.dir4 != 0 ||
       Input.press?(Input::USE) ||
       Input.press?(Input::BACK) ||
       Input.press?(Input::ACTION) ||
       Input.press?(Input::SPECIAL)

      @last_device = DEVICE_KEYBOARD
    end
  end

  def self.last_device
    return @last_device
  end

  def self.gamepad?
    return @last_device == DEVICE_GAMEPAD
  end

  def self.keyboard?
    return @last_device == DEVICE_KEYBOARD
  end

  def self.button_name(action)
    if gamepad?
      button = GAMEPAD_BUTTONS[action]
      return GAMEPAD_BUTTON_NAMES[button] || "Button #{button}"
    end

    return KEYBOARD_NAMES[action] || "?"
  end

  def self.press?(action)
    # Controller
    if gamepad? && defined?(Input::Controller) && Input::Controller.connected?
      button = GAMEPAD_BUTTONS[action]

      if button
        states = Input::Controller.raw_button_states
        return states[button]
      end
    end

    # Keyboard fallback
    input = ACTIONS[action]
    return Input.press?(input) if input

    return false
  end

  def self.trigger?(action)
    # Controller
    if gamepad? && defined?(Input::Controller) && Input::Controller.connected?
      button = GAMEPAD_BUTTONS[action]

      if button
        states = Input::Controller.raw_button_states
        current = states[button]
        last = @last_button_states[action]

        @last_button_states[action] = current

        return current && !last
      end
    end

    # Keyboard fallback
    input = ACTIONS[action]
    return Input.trigger?(input) if input

    return false
  end

  @repeat_count = {}

  def self.repeat?(action)
    if trigger?(action)
      @repeat_count[action] = 0
      return true
    end

    if press?(action)
      @repeat_count[action] ||= 0
      @repeat_count[action] += 1
      return true if @repeat_count[action] >= 24 && @repeat_count[action] % 6 == 0
    else
      @repeat_count[action] = 0
    end

    return false
  end
  
  def self.set_keyboard_binding(action, input)
    ACTIONS[action] = input
    KEYBOARD_NAMES[action] = input.to_s
  end

  def self.set_controller_binding(action, button_index)
    GAMEPAD_BUTTONS[action] = button_index
  end

  def self.wait_for_controller_button
    loop do
      Graphics.update
      Input.update

      states = Input::Controller.raw_button_states rescue []
      states.each_with_index do |pressed, i|
        return i if pressed
      end
    end
  end
end